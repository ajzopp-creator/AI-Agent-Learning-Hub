## TRADING SESSION START - CURRENT PARAMETERS

```
Account Balance: $35,000
Base Risk per Trade: 1.5% = $525
Max Position: 5% = $1,750 (override only with overwhelming evidence)

Cash Balance (I provide): Available buying power for THIS trade - NOT account balance
For options: 5% limit applies to PREMIUM PAID not notional exposure

POSTURE-BASED RISK SCALING (HOT MARKET RULES):
When BOTH conditions are TRUE:
  1. risk_mode = "FULL" (from risk_config.json)
  2. avg_posture > 1.08 (8%+ market momentum above neutral)

Apply TIERED RISK based on HybridTier:
  - HT 6 (Minimum BUY): 2.0% = $700
  - HT 7 (Strong): 3.0% = $1,050
  - HT 8 (Excellent): 4.0% = $1,400
  - HT 9+ (Exceptional): 5.0% = $1,750

Otherwise: Standard 1.5% = $525 for all signals

AsymmetricSetups in HOT MARKET: Treat as HT 6 → 2.0%

THREE-GATE POSITION SIZING:
  Gate 1 (Risk): Risk$ ÷ (Entry - Stop) [uses tiered % if HOT MARKET]
  Gate 2 (Cash): User-provided per trade
  Gate 3 (Max): $1,750 or premium paid
  Final = SMALLEST of three gates

OPTIONS DISPLAY RULE:
  Always show targets/stops as: "Stock $XX.XX → Option ~$X.XX (+XX% gain)"
  Calculate option prices using delta estimates
  Show leverage multiple
  Spread check: (Ask - Bid) ÷ Mid ≤ 10%
  OI check: ≥150 contracts
  If either fails: Fallback to stock
```

---

## CHART READING PROTOCOL

When user posts chart image + STEP 1/2/3 data:

### STEP 1 CHART EXTRACTION (Do NOT ask for re-paste)

1. Read ThinkorSwim overlay for:
   - AnalysisTier (from overlay)
   - CandleTier (from overlay)
   - SetupScore/IG Score (from overlay)
   - FundamentalsTier (infer from HybridTier logic if not visible)

2. Reconstruct: `STEP 1 [TICKER] [Fund] [Anal] [Candle] [Setup] [STR] - [VERDICT]`

3. Validate HybridTier = Anal + Fund ≥6 for BUY/ASYM signals

4. Apply verdict logic (no re-asking for diagnostics)

### PATTERN IDENTIFICATION (Do NOT ask for pattern type)

1. Examine daily chart structure:
   - **Cup shape**: rounded bottom, 7-65 weeks, volume dries at bottom
   - **Handle**: gentle descent from rim, 4 days - 4 weeks, bread & butter pattern
   - **High Handle**: forms AFTER breakout, 4 days - 4 weeks
   - **Flat Base**: long horizontal consolidation ≥5 weeks
   - **Double Bottom**: W formation, two buy points

2. Look for 60-min confirmation inside handle (mini cup-and-handle)

3. Assign PatternType directly (don't ask user)

4. Determine BreakoutVerdict from volume/price action at breakout point

---

## STEP 2 EXECUTION (Position Sizing with Posture Integration)

1. **Load risk_config.json** to check market posture
2. **Determine Risk Tier**:
   ```
   IF (risk_mode == "FULL" AND avg_posture > 1.08):
       IF HybridTier >= 9: risk_pct = 5.0%
       ELIF HybridTier >= 8: risk_pct = 4.0%
       ELIF HybridTier >= 7: risk_pct = 3.0%
       ELSE (HT 6): risk_pct = 2.0%
   ELSE:
       risk_pct = 1.5%  # Standard
   ```
3. **Calculate Gates**:
   - Gate 1 (Risk): `(account_balance × risk_pct) ÷ (entry - stop)`
   - Gate 2 (Cash): `cash_available ÷ entry`
   - Gate 3 (Max): `$1,750 ÷ entry` (for stocks)
4. **Final Position** = SMALLEST of three gates
5. **Calculate Targets**: T1 = resistance, T2 = trailing
6. **Show Stock Fallback** with notional exposure check

---

## STEP 3 EXECUTION (Options Viability)

1. Parse option data: `[Symbol][ExpiryStrike][Bid/Ask][OI][Delta]`
2. Calculate spread %: `(Ask - Bid) ÷ ((Ask + Bid) ÷ 2)`
3. Check OI ≥150
4. If BOTH pass: Show option prices + leverage
5. If either fails: REJECT and use stock fallback
6. Show: `"Stock $XX.XX → Option ~$X.XX (+XX% gain)"` format

---

## DYNAMIC TARGET LOGIC (2-TRANCHE WITH TOUCH COUNT VALIDATION)

### THE RULE: Resistance-Based Exits with Zone Strength Confirmation

**Do NOT use fixed 2× ATR targets.**

Instead:

1. **Scan for resistance levels** on 3-year weekly chart (or relevant timeframe)
   - Identify: recent highs, consolidation tops, breakout zones, major support/resistance clusters

2. **Validate zone strength using TOUCH COUNT**
   - **3+ touches** within ±0.50% band = **Strong zone** (60%+ confidence) → GREEN label
   - **2 touches** = **Moderate zone** (50% confidence) → YELLOW label
   - **1 touch** = **Weak zone** (40% confidence) → RED label

3. **Check for resistance within 5–10% above entry**
   - If Strong/Moderate zone exists → **Tranche 1 exit = that resistance level**
   - If no resistance in 5–10% range → Use 2× ATR as floor, look further for Tranche 1

4. **Identify next major resistance** (typically 7–15% away, validated by touch count)
   - This becomes **Tranche 2 trailing zone**

5. **Tranche 2 uses TRAILING STOP** (not fixed TP)
   - SL = Weekly Close - (1.5 × Weekly ATR)
   - Update every Friday close
   - Exit when SL is hit OR major breakout resistance breaks

---

## 2-TRANCHE STRUCTURE WITH ZONE CONFIDENCE

### TRANCHE 1 (First Exit - Lock Base Profit)

- **Exit Trigger**: First major resistance within 5–10% (preferably 3+ touches for Strong confidence)
- **Position Size**: Approximately 50% of total
- **Profit**: Lock-in gains at resistance confirmation
- **SL Move**: Raise stop loss to protect entry (breakeven + buffer)
- **Action**: Move to Tranche 2 management
- **Zone Confidence Color**:
  - GREEN (Strong, 3+ touches) = High probability
  - YELLOW (Moderate, 2 touches) = Acceptable probability
  - RED (Weak, 1 touch) = Lower probability, consider caution

### TRANCHE 2 (Trailing Exit - Capture Breakout)

- **Exit Trigger**: Trailing stop = Close - (1.5 × Weekly ATR)
- **Position Size**: Remaining 50%
- **Update Frequency**: Every Friday close
- **Exit Conditions**:
  - Stop loss is hit → Exit entire remaining position
  - Major resistance break (e.g., $34.50+) → Exit on confirmation or trail aggressively
- **Zone Confidence**: Secondary resistance validated by touch count (ideally 2+ touches for Moderate/Strong)

---

## WHEN TO ADD TRANCHE 3

Current account: $35,000
**Add Tranche 3 structure when account reaches: $43,750** (25% increase)

At that point, use 3-tranche with each tranche at ~33% of position, final tranche trailing to breakout.

---

## 27-COLUMN OUTPUT (ALL SETUPS - v2.3 WITH POSTURE INTEGRATION)

When processing batch:

1. Output ALL tickers in SINGLE continuous table (BUY + NO SIGNAL together)
2. **NO blank rows between entries** (every row is data)
3. For BUY/ASYM: Show Tranche 1 exit in TPLevel, Tranche 2 as trailing in Comments
4. For NO SIGNAL: Show "--" for trading-related columns
5. Include PatternType + BreakoutVerdict for ALL (even if "-" for no-signal)
6. **Add touch count validation** in Comments (T1/T2 zone strength)
7. **Include posture context** in SimulationNotes if HOT MARKET applied
8. Tab-delimited, Excel-ready
9. NO stray placeholders

### TPLevel Column Format (2-Tranche with Zone Strength):
```
Tranche 1 @ $X.XX (Strong/Moderate/Weak) / Trail from $Y.YY
Example: $30.73 (Strong - 5 touches) / Trail from $34.00 (Moderate - 2 touches)
```

### Comments Column (Tranche Details with Zone Validation + Posture):
```
[Shares]sh @ $[Entry], SL $[Stop]. 
[If HOT MARKET: "HOT MARKET: [risk%] risk for HT[X]"]
T1: Sell [#]sh @ $[T1 Price] ($[Confidence], [touch count] touches), SL→$[New SL]. 
T2: Trail [#]sh with SL = Close - $[ATR Amount]. Secondary target $[T2 Price] ([touch count] touches).
Expected R:R [#.##]:1 if [T2 target] hit.
Zone Confidence: T1=[Color/Strength], T2=[Color/Strength]
```

### SimulationNotes Column (Include Posture Context):
```
[If HOT MARKET: "Posture: [value] (HOT MARKET), Risk Mode: FULL → [risk%] risk tier applied."]
[Gate information if relevant]
[Option viability results if tested]
```

---

## COLUMN SCHEMA (27 Columns - LOCKED)

```
Date | Symbol | SignalSource | Step1Verdict | PatternType | BreakoutVerdict | 
BreakoutVolumeMultiple | DistributionDayCount | FollowThroughDay | MarketDirection | 
RSvsSPY | FundamentalsTier | AnalysisTier | CandleTier | SetupScore | LiquidityTier | 
Traded | EntryPrice | TPLevel | SLLevel | StopLevel | RiskPct | AccountBalance | 
Outcome | RecheckStatus | SimulationNotes | Comments
```

---

## THINKSCRIPT INTEGRATION (P_115_buyTheDipChart_V101)

### Script Features
- **Touch count detection**: Counts price tests within ±0.50% band of each R/S level
- **Zone strength confidence**: 3+ touches = Strong (GREEN), 2 = Moderate (YELLOW), 1 = Weak (RED)
- **Integrated R/S zones**: 6-month lookback with multi-touch validation
- **T1/T2 auto-detection**: T1 = recent 3-month high (R1), T2 = major 6-month high (R_major)
- **Tranche targets display**: Shows touch count + confidence in labels

### Script Controls (Inputs)
```
showTopRowLabels = yes/no  (Default: no)
  → Controls all diagnostic labels (Fund, Tech, STR, Earnings, MTF, EG, Verdict, Fund Breakdown)

showRSZones = yes/no       (Default: no)
  → Controls R/S zone plot lines (R1, R_major, S1, S_major bands)
  → Linked to showTopRowLabels (both toggle together)
```

### Essential Labels (Always Visible)
```
║ TRANCHE TARGETS ║
T1 EXIT: $XX.XX | Touches: N (Strength)
T2 TRAIL: $XX.XX | Touches: N (Strength)

📊 LogEntry: [Symbol] | [Fund] | [Anal] | [Candle] | [Setup] | [STR] | [PA] | [Verdict]
```

### Visual Signals (Always Active)
- Yellow dot: BUY signal
- Magenta arrow: Price Action pattern (BOSS, Pin Bar, Inside Bar)
- Red points: Earnings avoid period
- Red/Light Red horizontal lines: Resistance zones (when showRSZones = yes)
- Green horizontal lines: Support zones (when showRSZones = yes)

---

## STRATEGIES

- **P_115**: Buy The Dip (anticipation/oversold recovery)
- **P_116**: Options Income Launchpad (bounce patterns)
- **P_117**: Outside Recommendations (email/message tracking)
- **P_118**: Eddie Z Breakouts (Cup & Handle, High Handle, Flat Base, Double Bottom)

---

## TRADE EXECUTION WORKFLOW

### PRE-ENTRY
```
☑ Load risk_config.json: Check market posture + risk mode
☑ Chart reading: Extract STEP 1 diagnostics
☑ Pattern ID: Assign PatternType + BreakoutVerdict
☑ Scan resistance: 3-year chart for levels + validate touch count
☑ Calculate position: Three-gate sizing with posture-adjusted risk
☑ Define exits: Tranche 1 (strong resistance), Tranche 2 (trailing SL)
☑ Confirm: R:R ≥ 2:1 expected, zones validated by 2+ touches
```

### AT ENTRY
```
☑ Buy position (Tranche 1 + Tranche 2 combined)
☑ Set hard SL in ThinkorSwim = Entry - (1× ATR)
☑ Set calendar alert for Tranche 1 exit price
☑ Set calendar alert for Friday close (Tranche 2 SL update)
☑ Log in 27-column table: EntryPrice, StopLevel, TPLevel (T1/T2 with touch counts)
☑ Note zone confidence: T1/T2 strength based on touch count validation
☑ Note posture context: If HOT MARKET, document risk tier applied
```

### AT TRANCHE 1 EXIT
```
☑ Sell Tranche 1 shares @ resistance level
☑ Calculate Tranche 1 profit
☑ Move hard SL in ThinkorSwim up to breakeven + buffer
☑ Shift focus to Tranche 2 trailing
☑ Update Comments: "T1 locked @ $X.XX (Strong/Moderate/Weak, N touches), protecting T2 with trail"
```

### EVERY FRIDAY (Tranche 2 Management)
```
☑ Calculate new SL = Weekly Close - (1.5 × Weekly ATR)
☑ If new SL > old SL → Update SL in ThinkorSwim
☑ If price crosses SL → Exit entire Tranche 2
☑ If new high → Trail SL aggressively
☑ Check zone confidence: If T2 zone touched again → reinforces strength
☑ Update Comments with SL adjustment + zone action
```

### AT POSITION CLOSE
```
☑ Log final exit price(s) and profit(s)
☑ Calculate realized R:R
☑ Update 27-column table: Outcome, RealizedRR
☑ Add Comments: "T1 @ $X.XX (Strong, 5T) (+$Y), T2 @ $Z.ZZ (Moderate, 2T) (+$W). R:R: M:1. Zones validated."
```

---

## EXAMPLE TRADE CARD (2-TRANCHE WITH ZONE CONFIDENCE + POSTURE)

```
SYMBOL: BKV
ENTRY: $29.35 | 63 shares (HOT MARKET: 3.0% risk for HT7) | Initial SL: $28.24 (1× ATR)

MARKET POSTURE: avg_posture 1.10, risk_mode FULL → HOT MARKET TIER APPLIED

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TRANCHE 1 (32 shares)
├─ Exit Trigger: $30.73 (weekly resistance)
├─ Zone Strength: Strong (5 touches in 6-month lookback)
├─ Confidence: GREEN (60%+ probability)
├─ Profit: +$44.16
└─ New SL: $29.50 (remaining 31 shares)

TRANCHE 2 (31 shares - TRAILING)
├─ SL = Weekly Close - $3.54 (1.5× Weekly ATR)
├─ Target Zone: $33.50–$34.50+
├─ Secondary Resistance: $34.00 (Moderate, 2 touches)
├─ Update: Every Friday close
└─ Exit: When SL is hit OR major resistance breaks

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Expected R:R if $34.00 hit: 2.70:1 ✅
Zone Confidence: T1=Strong (5T, GREEN), T2=Moderate (2T, YELLOW)
Risk Scaling: HOT MARKET 3.0% vs. Standard 1.5% (+$525 additional capital deployed)
```

---

## COMPREHENSIVE RISK SCALING TABLE

| Scenario | risk_mode | avg_posture | HybridTier | Risk % | Risk $ | Notes |
|----------|-----------|-------------|------------|--------|--------|-------|
| Standard | CAUTIOUS | Any | Any | 1.5% | $525 | Market weakness |
| Standard | FULL | ≤ 1.08 | 6 | 1.5% | $525 | Neutral/mild bull |
| Standard | FULL | ≤ 1.08 | 7 | 1.5% | $525 | Neutral/mild bull |
| Standard | FULL | ≤ 1.08 | 8 | 1.5% | $525 | Neutral/mild bull |
| **HOT** | **FULL** | **> 1.08** | **6** | **2.0%** | **$700** | Minimum BUY |
| **HOT** | **FULL** | **> 1.08** | **7** | **3.0%** | **$1,050** | Strong |
| **HOT** | **FULL** | **> 1.08** | **8** | **4.0%** | **$1,400** | Excellent |
| **HOT** | **FULL** | **> 1.08** | **9+** | **5.0%** | **$1,750** | Exceptional |

**AsymmetricSetups in HOT MARKET:** Treat as HT 6 → 2.0% risk

---

## NOTES

- Parameters reviewed monthly. Next review: Feb 2026
- Account updates trigger review when growth ≥10% or reaches $40K milestone
- Tranche 3 added when account reaches $43,750 (25% growth from $35K)
- **NEW v2.3**: Posture-based risk scaling with HOT MARKET tiered allocations
  - HT 6: 2.0%, HT 7: 3.0%, HT 8: 4.0%, HT 9+: 5.0%
  - Triggered when risk_mode = FULL AND avg_posture > 1.08
- **v2.2**: Touch count validation for zone strength (3+ touches = Strong, 2 = Moderate, 1 = Weak)
- **v2.2**: P_115_buyTheDipChart_V101 with integrated R/S zone detection

---
