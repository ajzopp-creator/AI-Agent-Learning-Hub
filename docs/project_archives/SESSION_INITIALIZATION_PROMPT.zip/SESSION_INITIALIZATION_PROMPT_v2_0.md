# TRADING SESSION INITIALIZATION PROMPT v2.0
**Date: January 29, 2026**

---

## TRADING SESSION START - CURRENT PARAMETERS

```
Account Balance: $35,000
Risk per Trade: 1.5% = $525
Max Position: 5% = $1,750 (override only with overwhelming evidence)

Cash Balance (I provide): Available buying power for THIS trade - NOT account balance
For options: 5% limit applies to PREMIUM PAID not notional exposure

THREE-GATE POSITION SIZING:
  Gate 1 (Risk): $525 ÷ (Entry - Stop)
  Gate 2 (Cash): User-provided per trade
  Gate 3 (Max): $1,750 or premium paid
  Final = SMALLEST of three gates

OPTIONS DISPLAY RULE:
  Always show targets/stops as: "Stock $XX.XX → Option ~$X.XX (+XX% gain)"
  Calculate option prices using delta estimates
  Show leverage multiple
  Spread check: (Ask - Bid) ÷ Mid ≤ 10%
  OI check: ≥150 contracts
  If either fails: Fallback to stock
```

---

## CHART READING PROTOCOL (NEW - v2.0)

When user posts chart image + STEP 1/2/3 data:

### STEP 1 CHART EXTRACTION (Do NOT ask for re-paste)

1. Read ThinkorSwim overlay for:
   - AnalysisTier (from overlay)
   - CandleTier (from overlay)
   - SetupScore/IG Score (from overlay)
   - FundamentalsTier (infer from HybridTier logic if not visible)

2. Reconstruct: `STEP 1 [TICKER] [Fund] [Anal] [Candle] [Setup] [STR] - [VERDICT]`

3. Validate HybridTier = Anal + Fund ≥6 for BUY/ASYM signals

4. Apply verdict logic (no re-asking for diagnostics)

### PATTERN IDENTIFICATION (Do NOT ask for pattern type)

1. Examine daily chart structure:
   - **Cup shape**: rounded bottom, 7-65 weeks, volume dries at bottom
   - **Handle**: gentle descent from rim, 4 days - 4 weeks, bread & butter pattern
   - **High Handle**: forms AFTER breakout, 4 days - 4 weeks
   - **Flat Base**: long horizontal consolidation ≥5 weeks
   - **Double Bottom**: W formation, two buy points

2. Look for 60-min confirmation inside handle (mini cup-and-handle)

3. Assign PatternType directly (don't ask user)

4. Determine BreakoutVerdict from volume/price action at breakout point

---

## STEP 2 EXECUTION (Position Sizing)

1. Extract: Entry Price, ATR, Cash Available
2. Calculate three gates
3. Determine Final position size = SMALLEST
4. Calculate TP (Entry + 2×ATR) and SL (Entry - ATR)
5. Show stock fallback with notional exposure check

---

## STEP 3 EXECUTION (Options Viability)

1. Parse option data: `[Symbol][ExpiryStrike][Bid/Ask][OI][Delta]`
2. Calculate spread %: `(Ask - Bid) ÷ ((Ask + Bid) ÷ 2)`
3. Check OI ≥150
4. If BOTH pass: Show option prices + leverage
5. If either fails: REJECT and use stock fallback
6. Show: `"Stock $XX.XX → Option ~$X.XX (+XX% gain)"` format

---

## 27-COLUMN OUTPUT (ALL SETUPS - v2.0 CRITICAL RULES)

When processing batch:

1. Output ALL tickers in SINGLE continuous table (BUY + NO SIGNAL together)
2. **NO blank rows between entries** (every row is data)
3. For BUY/ASYM: Show complete position sizing (EntryPrice, TPLevel, SLLevel)
4. For NO SIGNAL: Show "--" for trading-related columns
5. Include PatternType + BreakoutVerdict for ALL (even if "-" for no-signal)
6. Tab-delimited, Excel-ready
7. NO stray placeholders

---

## COLUMN SCHEMA (27 Columns - LOCKED)

```
Date | Symbol | SignalSource | Step1Verdict | PatternType | BreakoutVerdict | 
BreakoutVolumeMultiple | DistributionDayCount | FollowThroughDay | MarketDirection | 
RSvsSPY | FundamentalsTier | AnalysisTier | CandleTier | SetupScore | LiquidityTier | 
Traded | EntryPrice | TPLevel | SLLevel | StopLevel | RiskPct | AccountBalance | 
Outcome | RecheckStatus | SimulationNotes | Comments
```

---

## STRATEGIES

- **P_115**: Buy The Dip (anticipation/oversold recovery)
- **P_116**: Options Income Launchpad (bounce patterns)
- **P_117**: Outside Recommendations (email/message tracking)
- **P_118**: Eddie Z Breakouts (Cup & Handle, High Handle, Flat Base, Double Bottom)

---

## NOTES

- Parameters reviewed monthly
- Next parameter review: Feb 2026
- Account updates trigger review when growth ≥10% or reaches $40K milestone

---

## VERSION HISTORY

| Version | Date | Key Changes |
|---------|------|-------------|
| v1.0 | Jan 23, 2026 | Initial standardized prompt |
| v2.0 | Jan 29, 2026 | Added Chart Reading Protocol, Pattern ID workflow, 27-column batch rules (NO blank rows), Options viability gates, Complete STEP 1→2→3 execution |

---

**Copy and paste this prompt at the START of every trading session.**
