from fastmcp import FastMCP
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name('catalog.db')
mcp = FastMCP('catalog-db')


def conn():
    return sqlite3.connect(DB_PATH)


@mcp.resource('db://tables')
def list_tables():
    with conn() as c:
        rows = c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    return {'tables': [r[0] for r in rows]}


@mcp.tool()
def table_info(table_name: str):
    with conn() as c:
        rows = c.execute(f"PRAGMA table_info({table_name})").fetchall()
    return [{'cid': r[0], 'name': r[1], 'type': r[2], 'notnull': r[3], 'default': r[4], 'pk': r[5]} for r in rows]


@mcp.tool()
def sample_rows(table_name: str, limit: int = 5):
    with conn() as c:
        rows = c.execute(f'SELECT * FROM {table_name} LIMIT ?', (limit,)).fetchall()
        cols = [d[0] for d in c.description]
    return {'columns': cols, 'rows': [dict(zip(cols, r)) for r in rows]}


if __name__ == '__main__':
    mcp.run(transport='sse', host='127.0.0.1', port=8000)
