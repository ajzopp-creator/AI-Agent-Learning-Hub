# P_800 Obsidian Interface Layer — Part 2: Bases, Dashboard & Build Plan
**Companion to:** P_800_Interface_Arch_Part1_Schemas_v1_0.md
**Version:** 1.0
**Created:** 2026-05-22

---
## 4. BASES CONFIGURATION

### 4.1 P115_Evaluations.base

```
filter:   file.inFolder("TradeManagement/P115")
sort:     date desc
columns:  date, symbol, step1_verdict, setup_score, traded, outcome, why_code
```

### 4.2 P300_Signals.base

```
filter:   file.inFolder("TradeManagement/P300")
sort:     date desc
columns:  date, ticker, signal, signal_horizon, h5_win_rate, h10_win_rate, h5_mean_ret, n_matches
```

### 4.3 P400_Trades.base

```
filter:   file.inFolder("TradeManagement/P400")
sort:     date desc
columns:  date, ticker, account_id, council_verdict, lifecycle_status, realized_pnl, why_code
```

### 4.4 P020_Performance.base

```
filter:   file.inFolder("TradeManagement/P020")
sort:     close_date desc
columns:  close_date, symbol, account_id, system, realized_pnl, realized_R, outcome, sig_code
```

### 4.5 Open_Positions.base

```
filter:   lifecycle_status == "OPEN" OR (traded == "Y" AND outcome IS NULL)
sort:     date asc
columns:  date, ticker, source, entry_price, stop_price, target_1, account_id, days_held
```

### 4.6 KB_Articles.base

```
filter:   file.inFolder("KnowledgeBase")
sort:     date desc
columns:  date, title, kb_type, origin, tags, ticker_relevance, sector
```

---

## 5. DASHBOARD DESIGN

`Dashboard.md` is the daily entry point — replaces the freeform daily note.
Updated by Python writers on each project run. Manual market notes appended by Tony.

```markdown
---
date: 2026-05-22
session_status: open
---

# AJZ Strategies Dashboard — Friday, May 22, 2026

## Open Positions
![[Open_Positions.base]]

## Today's P_115 Signals
![[P115_Evaluations.base]]   ← filter to today in base definition

## Recent P_300 Signals (Last 7 Days)
![[P300_Signals.base]]       ← filter last 7 days in base definition

## P_400 Active Trades
![[P400_Trades.base]]        ← filter lifecycle_status == OPEN

## Recent P_020 Performance (Last 10)
![[P020_Performance.base]]   ← limit 10 rows

## Knowledge Base — Recent
![[KB_Articles.base]]        ← limit 5 rows

## Market Notes
<!-- Manual entry — TOS + VantagePoint observations -->
```

---

## 6. PYTHON WRITER LAYER

Save path: `C:\Users\Trader\AI-Agent-Learning-Hub\projects\P_800_Automation_Note_Taking\scripts\obsidian_writers\`

| File | Lines | Purpose |
|------|-------|---------|
| `__init__.py` | 5 | package marker |
| `config.py` | 50 | vault path, folder map, schema versions |
| `frontmatter_utils.py` | 60 | dict → YAML frontmatter, slug generator |
| `p115_writer.py` | 80 | Excel tracker rows → P115/ notes |
| `p300_writer.py` | 70 | TXT report → P300/ notes |
| `p400_writer.py` | 70 | lifecycle TXT → P400/ notes (Phase 2) |
| `p020_writer.py` | 80 | SQLite v_trade_summary → P020/ notes |
| `dashboard_updater.py` | 60 | regenerate Dashboard.md header + date |
| `main.py` | 50 | CLI entry point — run all or single writer |
| `logger_setup.py` | 40 | logging |

Run mode: on-demand via `python -m obsidian_writers.main`
Environment: p140 conda

---

## 7. BUILD ROADMAP

| Phase | Deliverable | Status |
|-------|-------------|--------|
| 5A | Vault folder structure (P115/, P300/, P400/, P020/, KnowledgeBase/) | 🔵 Next |
| 5B | Six .base files (empty, structure only) | 🔵 Next |
| 5C | Dashboard.md initial version | 🔵 Next |
| 5D | `p115_writer.py` — Excel → P115/ | Planned |
| 5E | `p300_writer.py` — TXT → P300/ | Planned |
| 5F | `p020_writer.py` — SQLite → P020/ | Planned |
| 5G | KB Templater template + Web Clipper config | Planned |
| 5H | `p400_writer.py` — lifecycle → P400/ | Planned (after P_400 schema locked) |
| 6 | Dashboard.md → Claude Artifact (rich visual) | Future |

---

## 8. OPEN ITEMS

| # | Item | Owner | Notes |
|---|------|-------|-------|
| 1 | P_115 schema — additional fields beyond 27 cols | Tony + P_115 | Add as discovered during iteration |
| 2 | P_400 schema v1 — finalize TXT input fields | P_400 build session | Draft exists in P_400 doc |
| 3 | Dashboard update trigger — auto vs manual | Tony | Start automatic; revisit if cumbersome |
| 4 | KB capture workflow — Templater template needed | P_800 | Design in Phase 5G |
| 5 | Bases embedded view syntax — confirm Obsidian 1.12.7 support | Tony | Test ![[base]] embed on first build |
| 6 | P_020 WHY/SIG vocabulary lock (NEXT-1 in P_020 backlog) | Tony | Needed before p020_writer tags are reliable |

---

*P_800 Obsidian Interface Layer Architecture v1.0 — 2026-05-22*
*Owner: P_800 — feeds from P_115, P_300, P_400, P_020 (read-only relative to all)*
