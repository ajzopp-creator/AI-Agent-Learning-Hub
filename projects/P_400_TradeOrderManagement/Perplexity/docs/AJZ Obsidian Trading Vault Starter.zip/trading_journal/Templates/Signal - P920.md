---
type: signal_p920
signal_date: {{date}}
ticker: 
scan_type: Buyers-in-Control EOD scan
status: 
---

# {{ticker}} — P_920 Buyers-in-Control EOD Scan — {{date}}

> P_920 = an end-of-day "Buyers-in-Control" scan, another upstream source
> feeding P_115 (same pattern as P_117/P_118). Confirmed only as a
> `signal_rationale` mention inside a real P_115 note (`"P_920
> Buyers-in-Control EOD scan, P_115 BUY signal (HybridTier=8, Fund 4/4
> verified clean...)"`) — **no confirmed vault-write path of its own yet.**
> This template is a manual capture point until/unless a real generated
> P_920 note surfaces.

## Scan Result
- Candidate flagged: 
- EOD scan date: 

## Outcome after P_115 recheck
- [[TradeOrderManagement/P115/{{date}}_{{ticker}}]]
