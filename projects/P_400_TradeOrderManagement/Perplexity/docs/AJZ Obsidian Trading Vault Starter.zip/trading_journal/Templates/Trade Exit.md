---
type: trade_exit
date: {{date}}
ticker: 
entry_ref: 
result: 
r_multiple: 
outcome: 
cooldown_days: 
---

# Trade Exit — {{ticker}} — {{date}}

## What Happened
- 

## Realized R:R
- Original stop used for R calc (Plan §5.2 — never the moved stop):

## Mistakes
- 

## Improvements
- 

## Behavioral Judge Check (05)
- Was this exit rule-based or emotional?
- Any revenge-trade or override risk?

## Cooldown Applied
- SL Hit → 5 sessions | Manual Exit (pattern fail) → 10 sessions | 3 consecutive SL hits → halt 1 session portfolio-wide

## Attachments
- Screenshot:

## Linked Entry
- [[Journal/Trade Entries/{{date}}_{{ticker}}]]
