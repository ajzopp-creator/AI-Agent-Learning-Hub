---
source: P400
schema_version: "0.1"
signal_date: {{date}}
run_date: {{date}}
run_ts: 
ticker: 
write_route: 
written_by: P_400/cli_evaluate
note_version: 1
write_route_history: []
account_id: 
council_verdict: 
risk_mode: 
entry_price: 
stop_price: 
target_1: 
target_2: 
position_size: 
order_type: 
order_id: 
lifecycle_status: 
entry_date: 
close_date: 
realized_pnl: 
why_code: 
sig_code: 
p115_linked: false
p300_linked: false
drop_reason: 
option_method: 
option_structure: 
option_contract: 
option_entry_premium: 
option_stop_premium: 
option_target_premium: 
option_contracts: 
option_override: 
option_override_justification: 
iv_rank: 
spread_long_strike: 
spread_short_strike: 
spread_debit: 
spread_max_profit: 
spread_max_loss: 
spread_breakeven: 
---

# {{ticker}} - {{write_route}} (P400)

> CONFIRMED SCHEMA (v1.2) — this is not a guess. Every field above was copied
> from a real note your `obsidian_writers` module already wrote to
> `TradeOrderManagement/P400/<date>_<TICKER>.md`. You will almost never fill
> this template by hand — it exists as documentation of the real contract and
> as a manual-entry fallback (e.g. logging a trade placed outside the
> automated flow).
>
> Key fields to know:
> - `write_route`: PASS / BUY / BLOCK / TRADE (routing decision)
> - `council_verdict`: e.g. REVIEWED_NO_TRADE
> - `lifecycle_status`: e.g. DROPPED, OPEN, CLOSED
> - `risk_mode`: e.g. HALF, FULL, OFF (posture at time of evaluation)
> - `why_code`: which upstream system produced the candidate, e.g. P_300
> - `p115_linked` / `p300_linked`: booleans — **use these directly in
>   Dataview instead of manual backlinks** to show the signal chain
> - No `p117_linked`/`p118_linked` flags confirmed yet — P_117/P_118 appear
>   to feed P_115 upstream (see `why_code`/`upstream_source` on the P_115
>   note) rather than reaching P_400 as their own linked flag. Update this
>   note if a real P_400 sample ever shows otherwise.
> - `drop_reason`: e.g. RR_INVALID, RR_BELOW_MIN, SPREAD_TOO_WIDE, ADVERSE_DRIFT

## Notes (optional manual annotation)
- 
