---
type: signal_p300_council
date: {{date}}
ticker: 
asset_type: 
strike_exp: 
current_price: 
entry_price: 
stop_level: 
quantity: 
rr_target: 
framework_mode: normal
council_status: 
blocking_role: 
conditional_trigger: 
order_type_hint: 
limit_price_hint: 
---

# P_300 Council Review — {{ticker}} — {{date}}

## Council Input Form
- **Asset:** 
- **Symbol/Strike/Exp:** 
- **Current Price:** 
- **Original Entry Price:** 
- **Original Stop Level:** 
- **Position Quantity:** 
- **RR Goal / Target:** 
- **Framework Mode:** Normal / Risk-Off (CORRECTION)

## Council Review Response
1. **Validation:** 
2. **Calculated Inputs:**
   - Conditional Trigger (Stock): 
   - Order Type: 
   - Limit Price (Option): 
3. **Council Status:** Approve / Approve with Caution / Block / Override Required
   - Blocking role (if any): 

## Council Role Notes
- 01 Quant Strategist: 
- 02 Macro Economist: 
- 03 Momentum & Tape Reader: 
- 04 Risk Manager: 
- 05 Behavioral Judge: 

## Feeds Into
- [[TradeOrderManagement/P400/{{date}}_{{ticker}}]]
- [[Journal/Trade Entries/{{date}}_{{ticker}}]]
