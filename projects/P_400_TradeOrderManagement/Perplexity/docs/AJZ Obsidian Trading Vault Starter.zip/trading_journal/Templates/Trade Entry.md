---
type: trade_entry
date: {{date}}
ticker: 
system: 
setup: 
mode: normal
risk_pct: 
risk_dollars: 
confidence: 
p115_signal: 
p300_pattern: 
p300_council: 
p400_order: 
council_status: 
---

# Trade Entry — {{ticker}} — {{date}}

## Thesis
- 

## Chart Notes
- 

## Pre-Trade Checklist (Plan §3.4)
- [ ] Method: Chart-Based / Risk-Budget-First
- [ ] R:R ≥ 2:1
- [ ] Passes 3 gates + total open risk ≤ 5%
- [ ] Options: spread ≤ 10%, OI ≥ 150
- [ ] Override documented (if applicable)
- [ ] Council Status = Approve / Approve with Caution

## Council Chain (link the signals that cleared this trade)
- P_115 Regime: [[TradeOrderManagement/P115/{{date}}_{{ticker}}]]
- P_300 Pattern: [[TradeOrderManagement/P300/{{date}}_{{ticker}}]]
- P_300 Council Review: [[TradeOrderManagement/P300-Council/{{date}}_{{ticker}}]]
- P_400 Order: [[TradeOrderManagement/P400/{{date}}_{{ticker}}]]

## Related Analysis
- [[Analysis/Market Intel/{{date}}]]
- [[Analysis/Sector Rotation/{{date}}]]
