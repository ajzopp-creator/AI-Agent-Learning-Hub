---
type: signal_p400_batch
date: {{date}}
run_timestamp: 
session_date: 
cash_available: 
posture: 
screened_count: 
passed_tier1: 
evaluated: 
cumulative_risk_if_all_taken: 
heat_cap: 
heat_warning: 
---

# P_400 Batch Screen — {{date}}

Confirmed real fields (from `batch2b_<date>_<runtimestamp>.json`): `run_timestamp`,
`session_date`, `cash_available`, `posture` (seen value: `HALF` — confirm the
full set, likely FULL/HALF/OFF or similar), `screened_count`, `passed_tier1`,
`evaluated`, `candidates`, `skipped` (list of `{symbol, reason}` — reason is
`verdict=BLOCKED (<CODE>)`, e.g. `ADVERSE_DRIFT`, `RR_BELOW_MIN`),
`cumulative_risk_if_all_taken`, `heat_cap`, `heat_warning`.

## Candidates Evaluated
| Symbol | Outcome |
|---|---|
| | |

## Skipped
| Symbol | Reason |
|---|---|
| | |

## Portfolio Heat Check (Council Role 01 — Quant Strategist)
- Heat cap: 
- Cumulative risk if all taken: 
- Within budget? 

## Posture Check (Council Role 02 — Macro Economist)
- Posture today: 
- Cash available: 
