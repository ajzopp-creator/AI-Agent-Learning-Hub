---
type: daily_review
date: {{date}}
---

# Daily Report — {{date}}

Field names below are the **confirmed real schema** from your `obsidian_writers` output, verified against actual `TradeOrderManagement/P300/2026-09-03_CRUS.md` and `TradeOrderManagement/P400/2026-09-03_CRUS.md` notes.

## P_300 Pattern Signals Today
```dataview
TABLE ticker AS "Ticker", signal AS "Signal", h5_win_rate AS "WR (h5)", h5_z_score AS "Z (h5)", h10_win_rate AS "WR (h10)", h10_z_score AS "Z (h10)", n_matches AS "n"
FROM "TradeOrderManagement/P300"
WHERE signal_date = this.date
SORT h5_z_score DESC
```

## P_115 Signals Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", strategy AS "Strategy"
FROM "TradeOrderManagement/P115"
WHERE signal_date = this.date
SORT ticker ASC
```
*(P_115 vault-write path/schema unconfirmed — placeholder pending a real sample note.)*

## P_117 Outside Recommendations Today
```dataview
TABLE ticker AS "Ticker", source_email AS "Source", status AS "Status"
FROM "TradeOrderManagement/P117"
WHERE signal_date = this.date
SORT ticker ASC
```

## P_118 Pattern Candidates Today
```dataview
TABLE ticker AS "Ticker", pattern_type AS "Pattern", step AS "Step", origin_date AS "Origin Scan"
FROM "TradeOrderManagement/P118"
WHERE signal_date = this.date
SORT ticker ASC
```
*(P_117/P_118 confirmed to exist only via mentions inside real P_115 rationale text — both placeholders pending real samples.)*

## P_920 Buyers-in-Control EOD Scan Today
```dataview
TABLE ticker AS "Ticker", status AS "Status"
FROM "TradeOrderManagement/P920"
WHERE signal_date = this.date
SORT ticker ASC
```
*(Confirmed only via one P_115 rationale mention — placeholder pending a real sample.)*

## P_400 — Approved / Trade-Worthy Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", entry_price AS "Entry", stop_price AS "Stop", target_1 AS "T1", target_2 AS "T2", position_size AS "Size", risk_mode AS "Mode"
FROM "TradeOrderManagement/P400"
WHERE signal_date = this.date AND (write_route = "BUY" OR write_route = "TRADE")
SORT ticker ASC
```

## P_400 — Passed / Blocked Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", council_verdict AS "Verdict", drop_reason AS "Drop Reason", why_code AS "Origin"
FROM "TradeOrderManagement/P400"
WHERE signal_date = this.date AND write_route != "BUY" AND write_route != "TRADE"
SORT ticker ASC
```

## Signal Chain Today (real p115_linked / p300_linked flags)
```dataview
TABLE ticker AS "Ticker", why_code AS "Origin", p115_linked AS "P115?", p300_linked AS "P300?", council_verdict AS "Verdict"
FROM "TradeOrderManagement/P400"
WHERE signal_date = this.date AND (p115_linked = true OR p300_linked = true)
SORT ticker ASC
```

## P_400 Batch Screen Today (posture / cash / heat)
```dataview
TABLE posture AS "Posture", cash_available AS "Cash", heat_cap AS "Heat Cap", cumulative_risk_if_all_taken AS "Cum. Risk", heat_warning AS "Warning"
FROM "TradeOrderManagement/P400-Batch"
WHERE date = this.date
```

## Trades Entered Today
```dataview
TABLE ticker AS "Ticker", setup AS "Setup", risk_pct AS "Risk %", council_status AS "Council"
FROM "Journal/Trade Entries"
WHERE date = this.date
```

## Trades Exited Today
```dataview
TABLE ticker AS "Ticker", result AS "Result", r_multiple AS "R", outcome AS "Outcome"
FROM "Journal/Trade Exits"
WHERE date = this.date
```

## Market Summary
- 

## Emotional State / Behavioral Judge Check (05)
- Did I force any trades today?
- Any overrides logged? Were they justified?

## Portfolio Heat Check (01 — Quant Strategist)
- Pulled automatically from the P_400 Batch Screen table above (heat_cap, cumulative_risk_if_all_taken).

## Lessons
- 
