---
source: P300
schema_version: "2.0"
signal_date: {{date}}
run_date: {{date}}
run_ts: 
ticker: 
write_route: 
written_by: P_300/daily_evaluate_pipeline
note_version: 1
write_route_history: []
signal: 
signal_horizon: 5
generated_dt: 
h5_win_rate: 
h5_mean_ret: 
h5_z_score: 
h5_class: 
h7_win_rate: 
h7_mean_ret: 
h7_z_score: 
h7_class: 
h10_win_rate: 
h10_mean_ret: 
h10_z_score: 
h10_class: 
h15_win_rate: 
h15_mean_ret: 
h15_z_score: 
h15_class: 
h20_win_rate: 
h20_mean_ret: 
h20_z_score: 
h20_class: 
top_analog_1: 
top_analog_2: 
top_analog_3: 
top_comp_dist_1: 
n_matches: 
---

# {{ticker}} - {{signal}} (P300)

> CONFIRMED SCHEMA (v1.2) — copied from a real note your P_300 pipeline
> already wrote to `TradeOrderManagement/P300/<date>_<TICKER>.md`. Like
> P_400, this folder is already automated — you'll rarely fill this by hand.
>
> `signal` is the overall classification (BUY/WATCH/PASS). Each horizon
> (h5/h7/h10/h15/h20, trading days) carries its own win_rate, mean_ret
> (percent), z_score, and class — VantagePoint evaluates multiple forward
> windows independently rather than collapsing to one number.

## Per-Horizon Stats
**h=5** | WR= | MR= | Z=
**h=7** | WR= | MR= | Z=
**h=10** | WR= | MR= | Z=
**h=15** | WR= | MR= | Z=
**h=20** | WR= | MR= | Z=

## Narrative
- 

## Chaikin Power Gauge (if pulled)
- Rating:
- Price:
