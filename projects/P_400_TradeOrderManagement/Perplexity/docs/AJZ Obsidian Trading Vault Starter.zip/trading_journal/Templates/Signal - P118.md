---
type: signal_p118
signal_date: {{date}}
ticker: 
step: STEP1
pattern_type: 
origin_date: 
status: 
---

# {{ticker}} — P_118 Pattern Candidate — {{date}}

> P_118 = internal chart-pattern scanner (observed examples: "High Handle
> candidate", "Cup and Handle breakout"). Confirmed only as a
> `signal_rationale` mention inside P_115 notes (`"P_118 High Handle
> candidate; P_115 recheck ASYM..."`, `"P_118_STEP1/..._reemit"` in
> signal_metadata.signal_source_link) — **no confirmed vault-write path of
> its own yet.** `step` (e.g. STEP1) suggests a multi-stage scan; `origin_date`
> is the original scan date if it differs from today (candidates can sit
> before being picked up/re-emitted).

## Pattern Detected
- Type: 
- Origin scan date: 

## Outcome after P_115 recheck
- [[TradeOrderManagement/P115/{{date}}_{{ticker}}]]
