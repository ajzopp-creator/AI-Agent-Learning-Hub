---
type: signal_p115
signal_date: {{date}}
ticker: 
write_route: 
strategy: 
upstream_source: 
confidence_level: 
fund_score: 
anal_score: 
candle_score: 
setup_score: 
str_score: 
hybrid_tier: 
fund_verified: 
roe_pct: 
debt_ratio_pct: 
fcf: 
ma200_pct: 
ma200_status: 
earnings_proximity: 
breakout_verdict: 
override: 
override_justification: 
guideline_entry: 
guideline_stop: 
guideline_target: 
regime: 
action: 
strength: 
volume_tag: 
vwap_z: 
vol_z: 
obv_z: 
cmf_z: 
rsi_z: 
macd_z: 
pct_gain_z: 
sumzz: 
---

# {{ticker}} — P_115 — {{date}}

> Two field blocks below because it's still unconfirmed whether these are the
> same system or two different ones (open question from v1.2) — fill in
> whichever actually applies and delete the other once you know.

## Block A — HybridTier scoring (confirmed real, from signal-archive evidence)
Seen in real `signal_rationale` text: component scores **Fund/Anal/Candle/Setup/STR**
roll up into **HybridTier** (e.g. `Fund 4, Anal 3, Candle 2, Setup 3, STR 0,
HybridTier 7`), plus a fundamental-verification pass/fail (ROE, Debt/Cap or
Debt/Equity, FCF via stockanalysis.com), a 200-MA regime check (e.g. `200-MA
19.8% NORMAL`), an earnings-proximity check, and for breakout strategies a
`BreakoutVerdict` (TrueBounce confirmation PASS/FAIL). `upstream_source` is
where the candidate came from before P_115's recheck — e.g. `P_117`
(external/outside rec), `P_118` (internal Cup-and-Handle/High-Handle scanner),
`P_920` (internal Buyers-in-Control EOD scan), or `direct`. `write_route` seen
values include `BUY`, `ASYM`, and presumably `WATCH`/`PASS`.

- Upstream source: P_117 / P_118 / P_920 / direct
- Strategy: breakout / dip_buy / pattern_analog
- Component scores: Fund __ / Anal __ / Candle __ / Setup __ / STR __ → HybridTier __
- Fund verification: ROE __% | Debt ratio __% | FCF __ | Pass/Fail: __
- 200-MA: __% | Status: NORMAL / other
- Earnings proximity: 
- Breakout verdict (if applicable): 
- Override (if any) + justification: 

## Block B — ThinkScript Regime Council chart read (original assumption, keep if still in use)
| Metric | Value |
|---|---|
| VWAP_Z | |
| VOL_Z | |
| OBV_Z | |
| CMF_Z | |
| RSI_Z | |
| MACD_Z | |
| PCT_GAIN_Z | |
| sumZZ | |

- Regime: 
- Action: 
- Strength: 
- Volume: 

## Chart Screenshot (if captured manually)
![[]]

## Feeds Into
- [[TradeOrderManagement/P400/{{date}}_{{ticker}}]]  (P_115 is signal-only — order management is fully owned by P_400)
- [[TradeOrderManagement/P300/{{date}}_{{ticker}}]]
- [[Journal/Trade Entries/{{date}}_{{ticker}}]]

## Upstream Signal
- [[TradeOrderManagement/P117/{{date}}_{{ticker}}]]  (if sourced from an outside recommendation)
- [[TradeOrderManagement/P118/{{date}}_{{ticker}}]]  (if sourced from the internal pattern scanner)
- [[TradeOrderManagement/P920/{{date}}_{{ticker}}]]  (if sourced from the Buyers-in-Control EOD scan)
