---
type: dashboard
---

# Daily Report — Live (Today)

Field names below are the **confirmed real schema** from your `obsidian_writers` output, verified against actual `TradeOrderManagement/P300/2026-09-03_CRUS.md` and `TradeOrderManagement/P400/2026-09-03_CRUS.md` notes. This note always shows *today's* activity. Use `Journal/Daily Reviews/<date>.md` (built from the Daily Review template) for the permanent per-day record.

## P_300 Pattern Signals — Today
```dataview
TABLE ticker AS "Ticker", signal AS "Signal", h5_win_rate AS "WR (h5)", h5_z_score AS "Z (h5)", h10_win_rate AS "WR (h10)", h10_z_score AS "Z (h10)", n_matches AS "n"
FROM "TradeOrderManagement/P300"
WHERE signal_date = date(today)
SORT h5_z_score DESC
```
*(h7/h15/h20 also exist on each note — open the note itself for the full 5-horizon breakdown, or add columns here if you want them visible at a glance.)*

## P_115 Signals — Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", strategy AS "Strategy"
FROM "TradeOrderManagement/P115"
WHERE signal_date = date(today)
SORT ticker ASC
```
*(P_115's own vault-write path/schema is still unconfirmed — placeholder using the shared-schema convention until you share a real generated P_115 note.)*

## P_117 Outside Recommendations — Today
```dataview
TABLE ticker AS "Ticker", source_email AS "Source", status AS "Status"
FROM "TradeOrderManagement/P117"
WHERE signal_date = date(today)
SORT ticker ASC
```
*(Confirmed to exist only as a mention inside real P_115 rationale text — no confirmed vault-write path of its own. Placeholder pending a real sample or a decision to log these manually.)*

## P_118 Pattern Candidates — Today
```dataview
TABLE ticker AS "Ticker", pattern_type AS "Pattern", step AS "Step", origin_date AS "Origin Scan"
FROM "TradeOrderManagement/P118"
WHERE signal_date = date(today)
SORT ticker ASC
```
*(Same caveat as P_117 — confirmed only via P_115 rationale mentions, e.g. "P_118_STEP1/..._reemit". Placeholder pending a real sample.)*

## P_920 Buyers-in-Control EOD Scan — Today
```dataview
TABLE ticker AS "Ticker", status AS "Status"
FROM "TradeOrderManagement/P920"
WHERE signal_date = date(today)
SORT ticker ASC
```
*(Same caveat as P_117/P_118 — confirmed only via one P_115 rationale mention ("P_920 Buyers-in-Control EOD scan, P_115 BUY signal..."). Placeholder pending a real sample.)*

## P_400 — Approved / Trade-Worthy — Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", entry_price AS "Entry", stop_price AS "Stop", target_1 AS "T1", target_2 AS "T2", position_size AS "Size", risk_mode AS "Mode"
FROM "TradeOrderManagement/P400"
WHERE signal_date = date(today) AND (write_route = "BUY" OR write_route = "TRADE")
SORT ticker ASC
```

## P_400 — Passed / Blocked — Today
```dataview
TABLE ticker AS "Ticker", write_route AS "Route", council_verdict AS "Verdict", drop_reason AS "Drop Reason", why_code AS "Origin"
FROM "TradeOrderManagement/P400"
WHERE signal_date = date(today) AND write_route != "BUY" AND write_route != "TRADE"
SORT ticker ASC
```

## Signal Chain — Today (real p115_linked / p300_linked flags)
```dataview
TABLE ticker AS "Ticker", why_code AS "Origin", p115_linked AS "P115?", p300_linked AS "P300?", council_verdict AS "Verdict", lifecycle_status AS "Status"
FROM "TradeOrderManagement/P400"
WHERE signal_date = date(today) AND (p115_linked = true OR p300_linked = true)
SORT ticker ASC
```

## Open Positions (lifecycle_status = OPEN)
```dataview
TABLE ticker AS "Ticker", entry_price AS "Entry", stop_price AS "Stop", target_1 AS "T1", target_2 AS "T2", entry_date AS "Entry Date"
FROM "TradeOrderManagement/P400"
WHERE lifecycle_status = "OPEN"
SORT entry_date DESC
```

## Trades Entered — Today (your journal)
```dataview
TABLE ticker AS "Ticker", setup AS "Setup", risk_pct AS "Risk %", council_status AS "Council"
FROM "Journal/Trade Entries"
WHERE date = date(today)
```

## Trades Exited — Today (your journal)
```dataview
TABLE ticker AS "Ticker", result AS "Result", r_multiple AS "R", outcome AS "Outcome"
FROM "Journal/Trade Exits"
WHERE date = date(today)
```

## P_400 Batch Screen — Today (posture / cash / heat)
```dataview
TABLE posture AS "Posture", cash_available AS "Cash", heat_cap AS "Heat Cap", cumulative_risk_if_all_taken AS "Cum. Risk", heat_warning AS "Warning"
FROM "TradeOrderManagement/P400-Batch"
WHERE date = date(today)
```
