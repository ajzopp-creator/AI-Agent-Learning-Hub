---
type: dashboard
---

# Mistake Tracker

Pulls every Trade Exit note where the "Mistakes" section is non-empty. Review weekly per Behavioral Judge (Role 05) — "Lesson capture and review."

```dataview
TABLE ticker AS "Ticker", date AS "Date", result AS "Result", r_multiple AS "R"
FROM "Journal/Trade Exits"
SORT date DESC
```

## Weekly Review Prompt
- Which mistakes repeated from last week?
- Any pattern of override discipline breaking down?
- Cooldown periods respected on every SL hit / manual exit?
