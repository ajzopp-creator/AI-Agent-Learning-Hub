---
type: dashboard
---

# Pattern Library

All P_300 VantagePoint pattern signals, grouped by classification. Field names confirmed against a real generated note (h5 horizon shown; swap `h5_*` for `h7_*`/`h10_*`/`h15_*`/`h20_*` to view other horizons).

## BUY Signals
```dataview
TABLE ticker AS "Ticker", signal_date AS "Signal Date", h5_win_rate AS "WR (h5)", h5_z_score AS "Z (h5)", n_matches AS "n"
FROM "TradeOrderManagement/P300"
WHERE signal = "BUY"
SORT signal_date DESC
```

## WATCH Signals
```dataview
TABLE ticker AS "Ticker", signal_date AS "Signal Date", h5_win_rate AS "WR (h5)", h5_z_score AS "Z (h5)", n_matches AS "n"
FROM "TradeOrderManagement/P300"
WHERE signal = "WATCH"
SORT signal_date DESC
```

## Signals That Reached P_400 (using the real p300_linked flag)
```dataview
TABLE ticker AS "Ticker", signal_date AS "Signal Date", council_verdict AS "P400 Verdict", write_route AS "Route"
FROM "TradeOrderManagement/P400"
WHERE p300_linked = true
SORT signal_date DESC
```
