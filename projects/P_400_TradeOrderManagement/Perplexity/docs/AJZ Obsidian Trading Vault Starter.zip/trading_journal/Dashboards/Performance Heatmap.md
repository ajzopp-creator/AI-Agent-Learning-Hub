---
type: dashboard
---

# Performance Heatmap

Simple win/loss + R distribution pulled straight from Trade Exit frontmatter. Requires the Dataview plugin (no extra JS needed for the table view below).

```dataview
TABLE date AS "Date", ticker AS "Ticker", result AS "Result", r_multiple AS "R"
FROM "Journal/Trade Exits"
SORT date DESC
```

## Rollups (fill in manually each week until you're ready to automate via the Python sync script)
- Win rate this week: 
- Average R (winners): 
- Average R (losers): 
- Expectancy: 
