r"""
FILE:        sync_p300_pattern_reports.py
VERSION:     1.1 (LIKELY UNNECESSARY - see note below)

NOTE (v1.1): A real sample confirmed P_300 already has its own obsidian_writers
equivalent (written_by: P_300/daily_evaluate_pipeline) that writes full,
correctly-formatted notes directly to TradeOrderManagement/P300/<date>_<TICKER>.md
with the exact schema in Templates/Signal - P300.md. You almost certainly do NOT
need this script for the main flow. It's kept only as a fallback for backfilling
from legacy Pipeline B outputs/reports/*.txt files, if any still exist outside
the automated path.
DATE:        2026-09-04
AUTHOR:      Tony / Perplexity
LAYER:       infrastructure (I/O only)
DESCRIPTION: Reads Pipeline B's daily report files
             (outputs/reports/<date>_<symbol>.txt) from the P_300 project and
             converts each into a TradeOrderManagement/P300 note in the Obsidian
             vault, so BUY/WATCH/PASS signals show up automatically in the
             Daily Report dashboard without manual copy-paste.

IMPORTANT: The exact text layout of outputs/reports/<date>_<symbol>.txt was
           not available when this script was written. The `parse_report()`
           function below is a stub with a documented best-guess regex set.
           Run it once against a real report file, compare the parsed dict
           it prints, and adjust the regexes to match your actual output
           before relying on this for daily use.

USAGE (PowerShell):
    python sync_p300_pattern_reports.py `
        --reports "C:\Users\Trader\AI-Agent-Learning-Hub\projects\P_300_Vantage_Point_Pattern_Recognition\outputs\reports" `
        --vault "C:\Users\Trader\AI-Agent-Learning-Hub\trading_journal" `
        --date 2026-09-04
"""

import argparse
import re
from pathlib import Path


def parse_report(text: str) -> dict:
    """Best-guess parser for a Pipeline B report .txt. Adjust regexes to match
    your real report format - run with --dry-run first and compare output."""
    result = {
        "signal": None,
        "n_matches": None,
        "win_rate": None,
        "z_score": None,
    }

    sig = re.search(r"\b(BUY|WATCH|PASS)\b", text, re.IGNORECASE)
    if sig:
        result["signal"] = sig.group(1).upper()

    n = re.search(r"n\s*=\s*(\d+)", text)
    if n:
        result["n_matches"] = n.group(1)

    wr = re.search(r"(?:win.?rate|wr)\s*[=:]\s*([\d.]+)", text, re.IGNORECASE)
    if wr:
        result["win_rate"] = wr.group(1)

    z = re.search(r"z[-_]?score\s*[=:]\s*(-?[\d.]+)", text, re.IGNORECASE) or re.search(r"\bz\s*[=:]\s*(-?[\d.]+)", text, re.IGNORECASE)
    if z:
        result["z_score"] = z.group(1)

    return result


def write_note(vault_root: Path, date_str: str, ticker: str, parsed: dict, raw_text: str):
    target_dir = vault_root / "TradeOrderManagement" / "P300"
    target_dir.mkdir(parents=True, exist_ok=True)
    filepath = target_dir / f"{date_str}_{ticker}.md"

    fm = [
        "---",
        "type: signal_p300_pattern",
        f"date: {date_str}",
        f"ticker: {ticker}",
        f"signal: {parsed.get('signal') or ''}",
        f"n_matches: {parsed.get('n_matches') or ''}",
        f"win_rate: {parsed.get('win_rate') or ''}",
        f"z_score: {parsed.get('z_score') or ''}",
        "data_origin_type: EVAL_SET",
        "---",
        "",
        f"# P_300 VantagePoint Pattern Signal — {ticker} — {date_str}",
        "",
        "## Source Report (raw)",
        "```",
        raw_text.strip(),
        "```",
        "",
        "## Feeds Into",
        f"- [[TradeOrderManagement/P300-Council/{date_str}_{ticker}]]",
        "",
    ]
    filepath.write_text("\n".join(fm), encoding="utf-8")
    print(f"Wrote: {filepath}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--reports", required=True, help="Path to Pipeline B outputs/reports folder.")
    p.add_argument("--vault", required=True, help="Vault root (containing the Trading folder).")
    p.add_argument("--date", required=True, help="YYYY-MM-DD - matches the report filename prefix.")
    p.add_argument("--dry-run", action="store_true", help="Print parsed fields, do not write notes.")
    args = p.parse_args()

    reports_dir = Path(args.reports)
    vault_root = Path(args.vault)

    matches = list(reports_dir.glob(f"{args.date}_*.txt"))
    if not matches:
        print(f"No report files found for {args.date} in {reports_dir}")
        return

    for report_file in matches:
        ticker = report_file.stem.replace(f"{args.date}_", "")
        text = report_file.read_text(encoding="utf-8", errors="replace")
        parsed = parse_report(text)

        if args.dry_run:
            print(f"{report_file.name} -> {parsed}")
            continue

        write_note(vault_root, args.date, ticker, parsed, text)


if __name__ == "__main__":
    main()
