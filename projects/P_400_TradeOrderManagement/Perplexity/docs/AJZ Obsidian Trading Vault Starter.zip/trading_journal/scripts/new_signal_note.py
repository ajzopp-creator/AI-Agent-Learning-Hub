r"""
FILE:        new_signal_note.py
VERSION:     1.0
DATE:        2026-09-04
AUTHOR:      Tony / Perplexity
LAYER:       infrastructure (I/O only - vault file writer)
DESCRIPTION: Quick CLI to create a correctly-formatted Obsidian note in the
             Trading vault from one of the P_115 / P_300 / P_400 templates,
             so you can paste a Council Review response or a P_400 order
             block straight from chat into the right vault folder without
             hand-typing frontmatter.

USAGE (PowerShell):
    python new_signal_note.py --vault "C:\Users\Trader\AI-Agent-Learning-Hub\trading_journal" `
        --type p300-council --ticker BAC --date 2026-09-04 `
        --field council_status="Approve with Caution" `
        --field framework_mode=normal `
        --body "paste the full council response text here"

    # Or pipe body text in (e.g. from clipboard via PowerShell Get-Clipboard):
    Get-Clipboard | python new_signal_note.py --vault "C:\Users\Trader\AI-Agent-Learning-Hub\trading_journal" `
        --type p400 --ticker BAC --date 2026-09-04

NOTES:
- --type accepts: p115, p117, p118, p920, p300, p300-council, p400, trade-entry, trade-exit
- --field can be repeated: --field key=value --field key2=value2
- Body text (positional --body, or stdin) is appended under a "## Notes / Pasted Content"
  heading at the end of the note so nothing you paste is lost, even if a field
  above isn't filled in yet.
- This is a starter script. It does not talk to the P_300 catalog DB, Pipeline B,
  or the P_400 skill directly - it only formats and writes vault notes. Wire it
  into your own automation (e.g. call it from a PowerShell function right after
  a Council Review response) whenever you're ready.
"""

import argparse
import sys
from pathlib import Path
from datetime import date as _date

FOLDER_MAP = {
    "p115": "TradeOrderManagement/P115",
    "p117": "TradeOrderManagement/P117",
    "p118": "TradeOrderManagement/P118",
    "p920": "TradeOrderManagement/P920",
    "p300": "TradeOrderManagement/P300",
    "p300-council": "TradeOrderManagement/P300-Council",
    "p400": "TradeOrderManagement/P400",
    "trade-entry": "Journal/Trade Entries",
    "trade-exit": "Journal/Trade Exits",
}

TYPE_TAG = {
    "p115": "signal_p115",
    "p117": "signal_p117",
    "p118": "signal_p118",
    "p920": "signal_p920",
    "p300": "signal_p300",
    "p300-council": "signal_p300_council",
    "p400": "signal_p400",
    "trade-entry": "trade_entry",
    "trade-exit": "trade_exit",
}


def parse_args():
    p = argparse.ArgumentParser(description="Create a vault note from a Trading template type.")
    p.add_argument("--vault", required=True, help="Path to the vault root that CONTAINS the 'Trading' folder.")
    p.add_argument("--type", required=True, choices=sorted(FOLDER_MAP.keys()))
    p.add_argument("--ticker", required=True)
    p.add_argument("--date", default=str(_date.today()), help="YYYY-MM-DD, defaults to today.")
    p.add_argument("--field", action="append", default=[], help="key=value, repeatable.")
    p.add_argument("--body", default=None, help="Body text to paste in. If omitted, reads stdin if piped.")
    return p.parse_args()


def build_frontmatter(note_type, date_str, ticker, extra_fields):
    lines = ["---", f"type: {note_type}", f"date: {date_str}", f"ticker: {ticker}"]
    for kv in extra_fields:
        if "=" not in kv:
            continue
        k, v = kv.split("=", 1)
        lines.append(f"{k.strip()}: {v.strip()}")
    lines.append("---")
    return "\n".join(lines)


def main():
    args = parse_args()

    vault_root = Path(args.vault)
    target_dir = vault_root / FOLDER_MAP[args.type]
    target_dir.mkdir(parents=True, exist_ok=True)

    body_text = args.body
    if body_text is None and not sys.stdin.isatty():
        body_text = sys.stdin.read()

    note_type = TYPE_TAG[args.type]
    frontmatter = build_frontmatter(note_type, args.date, args.ticker, args.field)

    filename = f"{args.date}_{args.ticker}.md"
    filepath = target_dir / filename

    if filepath.exists():
        print(f"WARNING: {filepath} already exists - appending timestamp to avoid overwrite.")
        filepath = target_dir / f"{args.date}_{args.ticker}_{_date.today().strftime('%H%M%S')}.md"

    content = [frontmatter, "", f"# {args.type.upper()} — {args.ticker} — {args.date}", ""]
    if body_text:
        content += ["## Notes / Pasted Content", "", body_text.strip(), ""]
    else:
        content += ["## Notes / Pasted Content", "", "(paste raw signal text here)", ""]

    filepath.write_text("\n".join(content), encoding="utf-8")
    print(f"Created: {filepath}")


if __name__ == "__main__":
    main()
