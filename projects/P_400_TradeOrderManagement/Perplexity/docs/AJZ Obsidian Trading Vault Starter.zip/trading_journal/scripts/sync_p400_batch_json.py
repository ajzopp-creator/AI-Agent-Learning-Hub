r"""
FILE:        sync_p400_batch_json.py
VERSION:     1.0
DATE:        2026-09-04
AUTHOR:      Tony / Perplexity
LAYER:       infrastructure (I/O only)
DESCRIPTION: Converts a P_400 batch screening JSON (e.g.
             batch2b_2026-09-03_20260903_154518.json) into a vault note under
             TradeOrderManagement/P400-Batch/<date>.md so the day's posture,
             cash, heat cap, and skip reasons show up in the Daily Report.

CONFIRMED FIELDS (from a real sample):
  run_timestamp, session_date, cash_available, posture, screened_count,
  passed_tier1, evaluated, candidates (list), skipped (list of
  {symbol, reason}), cumulative_risk_if_all_taken, heat_cap, heat_warning

USAGE (PowerShell):
    python sync_p400_batch_json.py `
        --batch-file "C:\...\batch2b_2026-09-03_20260903_154518.json" `
        --vault "C:\Users\Trader\AI-Agent-Learning-Hub\trading_journal"
"""

import argparse
import json
from pathlib import Path


def write_note(vault_root: Path, data: dict, date_str: str):
    target_dir = vault_root / "TradeOrderManagement" / "P400-Batch"
    target_dir.mkdir(parents=True, exist_ok=True)
    filepath = target_dir / f"{date_str}.md"

    candidates = data.get("candidates", [])
    skipped = data.get("skipped", [])

    fm = [
        "---",
        "type: signal_p400_batch",
        f"date: {date_str}",
        f"run_timestamp: {data.get('run_timestamp', '')}",
        f"session_date: {data.get('session_date', '')}",
        f"cash_available: {data.get('cash_available', '')}",
        f"posture: {data.get('posture', '')}",
        f"screened_count: {data.get('screened_count', '')}",
        f"passed_tier1: {data.get('passed_tier1', '')}",
        f"evaluated: {data.get('evaluated', '')}",
        f"cumulative_risk_if_all_taken: {data.get('cumulative_risk_if_all_taken', '')}",
        f"heat_cap: {data.get('heat_cap', '')}",
        f"heat_warning: {data.get('heat_warning', '')}",
        "---",
        "",
        f"# P_400 Batch Screen — {date_str}",
        "",
        "## Candidates Evaluated",
        "| Symbol |",
        "|---|",
    ]
    for c in candidates:
        fm.append(f"| {c} |" if not isinstance(c, dict) else f"| {c.get('symbol', c)} |")

    fm += ["", "## Skipped", "| Symbol | Reason |", "|---|---|"]
    for s in skipped:
        fm.append(f"| {s.get('symbol', '')} | {s.get('reason', '')} |")

    fm += [
        "",
        "## Portfolio Heat Check (Council Role 01 — Quant Strategist)",
        f"- Heat cap: {data.get('heat_cap', '')}",
        f"- Cumulative risk if all taken: {data.get('cumulative_risk_if_all_taken', '')}",
        f"- Warning: {data.get('heat_warning', 'None')}",
        "",
        "## Posture Check (Council Role 02 — Macro Economist)",
        f"- Posture: {data.get('posture', '')}",
        f"- Cash available: {data.get('cash_available', '')}",
        "",
    ]

    filepath.write_text("\n".join(fm), encoding="utf-8")
    print(f"Wrote: {filepath}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--batch-file", required=True, help="Path to the batch*.json file.")
    p.add_argument("--vault", required=True, help="Vault root (containing TradeOrderManagement/).")
    args = p.parse_args()

    batch_path = Path(args.batch_file)
    data = json.loads(batch_path.read_text(encoding="utf-8"))
    date_str = data.get("session_date") or batch_path.stem.split("_")[1]

    write_note(Path(args.vault), data, date_str)


if __name__ == "__main__":
    main()
